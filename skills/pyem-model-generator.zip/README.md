# pyEM Model Generator

A Claude skill that writes a new computational model for
[pyEM](https://github.com/shawnrhoads/pyEM) — the hierarchical Expectation-Maximization/MAP
package for fitting behavioral, reinforcement-learning, regression, and Bayesian models to
trial-by-trial data.

## What it does

Give it a task and a model (in your own words, or by attaching a paper), and it produces two
files:

- **`<modelname>.py`** — a model module with simulate/fit functions and a `ModelSpec` wrapper,
  structured exactly like pyEM's own models (`pyem.models.rl`, `pyem.models.glm`,
  `pyem.models.bayes`).
- **`<modelname>.ipynb`** — a parameter-recovery notebook: task/model description with the update
  and choice-rule equations written out, then code that simulates data, fits it back, and plots
  recovered vs. true parameters — the same format as pyEM's own example notebooks.

## How to invoke it

Just describe what you want in plain language, for example:

> "I need a pyEM model for a probabilistic reversal-learning task — two options, reward
> probabilities flip every 8 trials, single learning rate and inverse temperature."

> "Here's a paper (attached) that describes a two-step decision task with a hybrid model-based/
> model-free learner. Can you turn the model in the Methods section into a pyEM model?"

> "Can pyEM fit a Bayesian changepoint-detection model where subjects track a hidden reward rate
> that occasionally jumps?"

## What to have ready

The more of this you can provide up front, the fewer follow-up questions you'll get:

- **Task structure**: number of response options, roughly how many trials/blocks, what feedback
  looks like.
- **The model's mechanics**: the update rule (how a value or belief changes after each trial) and
  the choice rule (how that value/belief becomes an observed response). Equations are ideal, but a
  clear verbal description works too.
- **Free parameters**: what they're called, their natural range (e.g. a learning rate in [0,1]),
  and what they mean psychologically.
- **A paper or supplemental materials**, if you have one — attach it and the skill will read the
  Methods/Results sections directly rather than asking you to transcribe the equations.

If you don't have all of this, that's fine — the skill will ask, with suggested defaults, rather
than guessing silently. It will also tell you plainly (before generating anything) if what you're
describing doesn't actually fit how pyEM fits models — for example, if it needs a fundamentally
intractable likelihood or an unbounded/nonparametric parameter count.

## Requirements

The skill itself doesn't need `pyem` installed — its reference materials are self-contained:
`references/rl.py`/`glm.py`/`bayes.py`/`model_template.py` and their matching notebooks are copies
of pyEM's own model files, `references/model_template.ipynb` is a generic single-model
parameter-recovery notebook, and `references/pyem_api.md` documents the core `pyem` API
(`EMModel`/`.recover()`, `ModelSpec`, the math transforms) so the skill can write correct code
without importing the package. The **output**, however, does: `<modelname>.py`
imports from `pyem` (e.g. `from pyem.core.modelspec import ModelSpec`), so running or fitting the
generated model requires `pip install pyem` (or `pip install -e .` from a local pyEM checkout) in
whatever environment you use it in.

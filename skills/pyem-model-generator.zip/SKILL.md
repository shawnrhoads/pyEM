---
name: pyem-model-generator
description: Generate a new computational model for the pyEM package (hierarchical Expectation-Maximization with MAP estimation for fitting behavioral/RL/regression/Bayesian models) — produces a Python model module (sim/fit functions plus a ModelSpec wrapper, named after the model) and a matching parameter-recovery Jupyter notebook. Use this whenever a user wants to add, implement, or port a new computational/behavioral model into a pyEM-based project — including from a plain-language description of a task and model, from an attached journal article or supplemental methods section describing a paradigm to reimplement, or when they mention Rescorla-Wagner, reinforcement learning models, GLM/regression models of trial-level behavior, or Bayesian belief-updating models in the context of parameter fitting or EM. Also use it if a user describes a behavioral task and asks "how would I model this" or "can pyEM fit this" — even without naming the skill.
---

# pyEM Model Generator

## What this produces

Two files, following the exact structure pyEM's own models use:

- `<modelname>.py` — a standalone module with `<modelname>_sim`/`<modelname>_fit` functions and a
  `<modelname>_model = ModelSpec(...)` wrapper, importable in any project with `pyem` installed.
- `<modelname>.ipynb` — a parameter-recovery demo notebook mirroring `references/rl.ipynb`'s
  structure: markdown describing the task and model (with the update/choice-rule equations in
  LaTeX), then code cells that simulate data, fit it back, and plot recovered vs. true parameters.

Both are self-contained: they assume `pyem` is installed as a dependency (absolute
`from pyem.core.modelspec import ModelSpec`-style imports), not that they'll be dropped into an
actual pyEM repo checkout. This mirrors the reference files in `references/`, which are themselves
self-contained copies of the real `pyem/models/*.py` files — read them directly; nothing here
requires the actual `pyem` package to be installed or importable.

## Step 1 — Gather the specification

Before writing anything, you need to know:

1. **Task structure** — how many response options per trial (2? 4? continuous?), how many
   blocks/trials, and whether that varies by condition. If unstated, suggest the same defaults used
   throughout `references/rl.ipynb` (`nsubjects=100, nblocks=4, ntrials=24` is a reasonable
   general-purpose default; adjust to match whatever the task actually needs) and let the user
   confirm or override rather than picking silently and moving on.
2. **Outcome/feedback structure** — binary reward, probabilistic reward schedule, continuous
   outcome, or multiple simultaneous channels (e.g. self/other, gain/loss).
3. **The model itself** — the update rule (how a value estimate or belief changes trial to trial)
   and the choice/response rule (softmax over values? a link function on a linear predictor?
   posterior sampling?). If you have the actual equations (from the user or a paper), use them
   directly; don't approximate a described mechanism with a different one.
4. **Free parameters** — name, natural-space bounds, psychological/statistical meaning, and (if the
   optimizer will search in Gaussian/unbounded space, which is the pyEM convention) which transform
   maps Gaussian space to that bound — `norm2alpha` for (0,1), `norm2beta` for (0,20), or a custom
   transform for anything else.
5. **Behavioral-data shape** — what `<modelname>_fit` will receive as arguments beyond `params`
   (e.g. `choices, rewards`, or `X, Y`), and what shape/dtype each has.

**If the user attaches a paper, PDF, or supplemental materials**, read it directly — Methods/
Materials sections usually describe the task structure, and Results or a dedicated Computational
Model section usually gives the update equations and parameter list (sometimes in a table, or in
supplemental equations). State plainly what you extracted vs. what's still missing, and only ask
the user about genuine gaps — don't re-ask for things the paper already answered. If the paper
compares several candidate models, ask which one(s) to build; don't assume "the best-fitting one"
without confirmation, since that framing can change depending on what the user actually wants to do
with the model.

For anything still unresolved after all of this, ask the user directly with a concrete suggested
default — guessing silently produces a model that looks plausible but doesn't match what they
actually meant, which is worse than asking.

## Step 2 — Feasibility gate (before writing any file)

pyEM fits models via gradient-based optimization (BFGS) of a per-subject negative log-posterior,
with subjects sharing a population-level Gaussian prior updated across EM iterations. That
architecture has real limits — check these **before** generating anything:

- **Every free parameter must be a single scalar per subject.** Nonparametric parameter counts
  (e.g. a Dirichlet process with an unbounded number of components) don't fit this framework.
- **The trial-level likelihood must be point-evaluable in closed form** given the parameters and
  the subject's data. If the only way to get a likelihood is particle filtering, ABC, or another
  simulation-based approximation, this isn't a good fit for pyEM's optimizer.
- **The model must be forward-simulable trial by trial** — this is what the `_sim` function needs
  to do, and it's also what makes parameter recovery possible at all.

These aren't arbitrary rules — they're the actual mechanism pyEM uses to fit anything, so a model
that violates them won't just "fit poorly," it genuinely can't be expressed as a `_fit` function
that returns a sensible objective value. If a hard requirement fails, say so plainly, explain which
part of the description doesn't fit and why, and suggest a simplification if one exists (e.g. a
finite mixture instead of a nonparametric one). Don't generate files in this case.

One **soft** check, worth a warning but not a blocker: if the parameter count looks large relative
to the likely number of trials per subject (a rough rule of thumb: more than ~1 free parameter per
15-20 trials starts to strain identifiability), mention this and let the user decide whether to
proceed, simplify, or add more trials to the task design.

## Step 3 — Pick the closest reference family

Read the matching reference pair before writing anything — don't write from memory of what a
Rescorla-Wagner or GLM model "usually" looks like, since the exact bounds-checking style, output
dict shape, and `ModelSpec` wrapper conventions matter for consistency with the rest of pyEM.

| Task/model shape | Reference files |
|---|---|
| Discrete choice, trial-based value learning, softmax over learned values (Rescorla-Wagner and its variants — separate learning rates by valence, multiple simultaneous outcome recipients, more than 2 options, etc.) | `references/rl.py` + `references/rl.ipynb` |
| Continuous or binary trial-level outcome as a (possibly discounted or autoregressive) linear/logistic function of predictors — not a discrete-choice learning process | `references/glm.py` + `references/glm.ipynb` |
| Belief-updating over a small, fixed set of latent categories from sequential observations, no reward-based value learning | `references/bayes.py` + `references/bayes.ipynb` |
| None of the above fit the structure well | `references/model_template.py` — a generic, heavily-commented `ModelSpec` scaffold; adapt the closest family's helper patterns (allocation, bounds-checking style) as needed |

If a description mixes elements of two families (e.g. a discrete choice with a continuous
regression-style outcome), say so and propose which family to base the structure on, rather than
silently picking one.

## Step 4 — Generate `<modelname>.py`

Mirror the chosen reference file's shape exactly:

- Absolute `pyem.*` imports (`from pyem.core.modelspec import ModelSpec`,
  `from pyem.utils.math import ...`) — never relative imports (`from ..core...`), since this file
  must work standalone in any project that depends on `pyem`.
- `<modelname>_sim(params, ...)` and `<modelname>_fit(params, ..., prior=None, output="npl")`
  matching the chosen family's calling convention and output-dict shape.
  One bounds check per free parameter (return `1e7`, don't raise — matches every model in the
  package; the one narrow exception is that `_sim` functions in the RW family raise on
  out-of-bounds *natural-space* params, since those are meant to be caller-supplied "true" values,
  not something the optimizer searches over — follow whichever your chosen reference does).
- Any allocation/helper logic your model needs, inlined directly in this one file — don't split it
  into a separate `_common.py` the way the installed package does for `rl.py`/`glm.py`; those exist
  because multiple *sibling* models share code, and a brand-new single model has no sibling yet.
- `<modelname>_desc`, `<modelname>_id`, `<modelname>_spec`, and
  `<modelname>_model = ModelSpec(id=..., spec=..., desc=..., params=None, sim=..., fit=...)` at the
  bottom, in the same shape as every model in the reference files.

## Step 5 — Generate `<modelname>.ipynb`

Mirror `references/rl.ipynb`'s cell structure:

1. A title markdown cell.
2. A task-description markdown cell containing the update rule and choice/response rule as LaTeX
   (`$$ ... $$` blocks), using the same `\textbf{Label:}\quad` convention seen throughout
   `references/rl.ipynb` and `references/glm.ipynb` — don't just describe the model in prose when
   you have the actual equations.
3. A code cell that imports `<modelname>_model` and prints its `.id`, `.desc`, and `.spec`.
4. A code cell that generates "true" parameters for a set of simulated subjects (natural space).
5. A code cell that builds `EMModel(...)` and calls either `.recover(...)` (mirroring
   `references/rl.ipynb` and `references/bayes.ipynb`) or a manual simulate → fit → plot sequence
   (mirroring `references/glm.ipynb`) — whichever matches the chosen family's reference notebook.
6. A final plot of recovered vs. true parameters.
7. If a source paper was used, a closing markdown cell with the citation.

## Step 6 — Report back

Tell the user what was generated and where, any assumptions you made along the way (defaults you
picked, equations you inferred rather than were given directly), and how to sanity-check the
result — at minimum, that it requires `pyem` installed to run, and which cell to look at first.

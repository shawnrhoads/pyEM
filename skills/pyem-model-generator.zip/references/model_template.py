"""Generic ModelSpec scaffold for a new pyEM model that doesn't fit the RW
(references/rl.py), GLM (references/glm.py), or Bayesian belief-updating
(references/bayes.py) shape closely enough to adapt one of those directly.

Every pyEM model — regardless of family — follows the same four-part shape:

  1. A `<name>_sim(params, **kwargs) -> dict` function that generates
     synthetic behavior from natural-space parameters. Needed for parameter
     recovery (EMModel.recover()) and identifiability analysis.
  2. A `<name>_fit(params, *data_args, prior=None, output="npl") -> float | dict`
     function: the objective EMModel actually optimizes. `params` arrives in
     **Gaussian (unbounded) space** — transform to natural space and bounds-
     check at the top, before computing anything. `output="npl"`/`"nll"`
     returns a scalar (what the optimizer minimizes); `output="all"` returns
     a dict of diagnostics for post-hoc inspection.
  3. Bounds checks: one per free parameter, returning a large penalty
     (`1e7`) rather than raising, so gradient-based optimization can recover
     from wandering outside the valid region instead of crashing.
  4. Wrapper metadata (`<name>_desc`, `<name>_id`, `<name>_spec`, and
     `<name>_model = ModelSpec(...)`) that bundles the above with a
     human-readable description and a hand-authored identity — used for
     self-documentation, not required by EMModel/ModelComparison to function.

Replace every `# ---- YOUR ... ----` block below with the actual task/model
logic. Everything else (the calling convention, the bounds-check pattern, the
wrapper metadata block) should stay the same shape as shown here and in
references/rl.py, glm.py, bayes.py.
"""
import numpy as np
from pyem.core.modelspec import ModelSpec
from pyem.utils.math import norm2alpha, norm2beta, calc_fval
# If a parameter isn't naturally alpha- or beta-shaped, write your own
# Gaussian->natural transform instead of forcing norm2alpha/norm2beta to fit —
# e.g. `np.exp(x)` for a positive-only parameter with no upper bound, or `x`
# unchanged for a parameter that's already naturally real-valued.


def my_model_sim(params: np.ndarray, nblocks: int = 4, ntrials: int = 24, **kwargs) -> dict:
    """Generate synthetic behavior for `params.shape[0]` subjects.

    Args:
        params: natural-space parameters, shape (n_subjects, n_params). Column
            order must match `my_model_fit`'s parameter order exactly.
        nblocks, ntrials: task structure — adjust/replace with whatever
            actually parameterizes your task (number of options, trial types,
            etc).

    Returns:
        A dict with AT LEAST a "params" key (echoing the input, for
        `EMModel.recover()`'s bookkeeping) plus whatever trial-level arrays
        your `_fit` function will need as its behavioral-data arguments
        (e.g. "choices", "outcomes", "rt" — name these however makes sense
        for your task; `_fit`'s signature and `pr_inputs=[...]` in
        `EMModel.recover()` must use the same names).
    """
    nsubjects = params.shape[0]

    # ---- YOUR CODE HERE: unpack natural-space parameter columns ----
    # all_param1 = params[:, 0]
    # all_param2 = params[:, 1]

    # ---- YOUR CODE HERE: preallocate trial-level output arrays ----
    # choices = np.empty((nsubjects, nblocks, ntrials), dtype=object)
    # outcomes = np.zeros((nsubjects, nblocks, ntrials), dtype=float)
    # nll = np.zeros((nsubjects, nblocks, ntrials), dtype=float)

    rng = np.random.default_rng()

    for s in range(nsubjects):
        # ---- YOUR CODE HERE: pull this subject's parameter values ----
        for b in range(nblocks):
            # ---- YOUR CODE HERE: reset any per-block state (e.g. initial value estimates) ----
            for t in range(ntrials):
                # ---- YOUR CODE HERE: the generative process for one trial ----
                # 1. Compute a choice/response probability (or a continuous
                #    predicted outcome) from the current parameter values and
                #    task state.
                # 2. Sample (or compute) the trial's observed outcome.
                # 3. Update any latent state (value estimate, belief, etc.)
                #    using this trial's outcome and the free parameters.
                # 4. Record the per-trial negative log-likelihood contribution
                #    if you want `nll` returned here for diagnostics (optional
                #    — `_fit` recomputes its own `nll` independently).
                pass

    return {
        "params": params,
        # "choices": choices,
        # "outcomes": outcomes,
    }


def my_model_fit(params, *data_args, prior=None, output: str = "npl"):
    """Objective function EMModel optimizes for one subject.

    Args:
        params: parameters in **Gaussian (normalized) space** — this is what
            the optimizer is actually searching over. Transform to natural
            space first thing.
        *data_args: this subject's behavioral data, in the same order/shape
            your `_sim` function produces them (e.g. `choices, outcomes`).
            EMModel calls `fit_func(params, *all_data[i], prior=..., output=...)`,
            so the positional order here must match what you build `all_data`
            from in the generated notebook.
        prior: a Prior object with a `.logpdf()` method, supplied by the EM
            loop — pass straight through to `calc_fval`, don't touch it.
        output: "npl" (negative posterior likelihood, what the optimizer
            minimizes with a prior), "nll" (negative log-likelihood, no
            prior), or "all" (a dict of diagnostics for post-hoc inspection).

    Returns:
        float when output is "npl"/"nll"; dict when output is "all".
    """
    # ---- transform Gaussian-space params to natural space ----
    # param1 = norm2alpha(params[0])   # -> (0, 1), e.g. a rate/probability
    # param2 = norm2beta(params[1])    # -> (0, 20), e.g. an inverse temperature

    # ---- bounds checks: one per free parameter, return 1e7 (don't raise) ----
    # if not (0.0 <= param1 <= 1.0):
    #     return 1e7
    # if not (1e-5 <= param2 <= 20.0):
    #     return 1e7

    # ---- YOUR CODE HERE: replay the same generative process as `_sim`,
    # but driven by the OBSERVED data instead of sampling, accumulating the
    # negative log-likelihood of the observed choices/outcomes at each trial ----
    nll = 0.0
    # for b in range(nblocks):
    #     for t in range(ntrials):
    #         ... compute choice/outcome probability under current params ...
    #         nll += -np.log(probability_of_observed_outcome + 1e-12)
    #         ... update latent state using the OBSERVED outcome ...

    if output == "all":
        return {
            "params": [],  # e.g. [param1, param2] in natural space
            "nll": nll,
            # include whatever trial-level diagnostics are useful to inspect later
        }

    return calc_fval(nll, params, prior=prior, output=output)


# ---------------------------------------------------------------------------
# Wrapper metadata — purely descriptive, but keep this shape for consistency
# with every other model in pyem.models.*
# ---------------------------------------------------------------------------
my_model_desc = """One or two sentences describing the task and the model's
generative process. Always end with: Free parameters: <name> (<meaning>,
bounds), <name> (<meaning>, bounds), ..."""
my_model_id = "my_model"  # short, lowercase, unique within your project
my_model_spec = {
    # Free-form and hand-authored — there is no fixed vocabulary to satisfy.
    # Group by conceptual role however makes sense for this model, e.g.:
    "rl": {"softmax": ["param2"], "rw": ["param1"]},
}
my_model = ModelSpec(
    id=my_model_id, spec=my_model_spec, desc=my_model_desc.strip(),
    params=None, sim=my_model_sim, fit=my_model_fit,
)

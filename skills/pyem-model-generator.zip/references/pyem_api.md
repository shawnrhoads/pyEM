# pyEM core API — reference for generated code

This file documents the **exact API surface** that a generated `<modelname>.py`
and its recovery notebook call into. It exists because you often won't have the
`pyem` package installed or importable while writing the model — so instead of
guessing the signatures of `EMModel`, `.recover()`, `ModelSpec`, or the math
transforms, read the contracts here. These signatures are copied from the real
`pyem` source and are what the generated code must match to run once the user
does have `pyem` installed.

The model files in this same `references/` folder (`rl.py`, `glm.py`,
`bayes.py`, `model_template.py`) show these APIs *in use*; this file is the
authoritative description of the APIs *themselves*.

## Contents

1. Where things live (import paths)
2. `ModelSpec` — the model wrapper
3. `pyem.utils.math` — parameter transforms and the objective helper
4. The `_sim` / `_fit` contract (how `EMModel` calls your two functions)
5. `EMModel` — fitting and parameter recovery
6. Gaussian space vs natural space (the one thing that trips everyone up)

---

## 1. Where things live

Generated files use **absolute** imports (never relative `from ..core`), so
they work in any project that merely depends on `pyem`:

```python
from pyem import EMModel                       # high-level fit/recover interface
from pyem.core.modelspec import ModelSpec      # the model wrapper dataclass
from pyem.utils.math import norm2alpha, norm2beta, calc_fval, softmax
```

`EMModel` and `FitResult` are re-exported from the top-level `pyem` package, so
`from pyem import EMModel` is the idiomatic form (that's what the example
notebooks use). `ModelSpec` and the math helpers are imported from their
submodules.

---

## 2. `ModelSpec`

A frozen dataclass that bundles a model's identity and its two entry points.
Nothing in `EMModel` *requires* a `ModelSpec` to function — it's a
self-documenting convenience — but every model in the package defines one, so a
generated model should too.

```python
@dataclass(frozen=True)
class ModelSpec:
    id: str          # short, lowercase, unique — e.g. "rw1a1b"
    spec: dict       # hand-authored; free-form grouping of params by role
    desc: str        # human-readable description; end with the free-param list
    params: Callable | None   # almost always None
    sim: Callable    # the <modelname>_sim function
    fit: Callable    # the <modelname>_fit function
```

`spec` has **no fixed vocabulary** — it's a descriptive dict you author to group
the parameters however makes sense (e.g. `{"rl": {"softmax": ["beta"], "rw":
["alpha"]}}`). It's for documentation only.

Access pattern used in notebooks: `model.id`, `model.desc`, `model.spec`,
`model.sim`, `model.fit`.

---

## 3. `pyem.utils.math`

These are the **only** built-in transforms. If a parameter isn't naturally
alpha- or beta-shaped, write your own Gaussian→natural transform inline (e.g.
`np.exp(x)` for a positive-only unbounded parameter, or `x` unchanged for a
real-valued one) rather than forcing one of these to fit.

| Function | Signature | Maps | Use for |
|---|---|---|---|
| `norm2alpha(x)` | `(x) -> ndarray` | ℝ → (0, 1) | learning rates, mixing weights, probabilities |
| `norm2beta(x, max_val=20.0)` | `(x, max_val) -> ndarray` | ℝ → (0, max_val) | softmax inverse temperature |
| `alpha2norm(a)` | inverse of `norm2alpha` | (0,1) → ℝ | natural → Gaussian (rarely needed directly) |
| `beta2norm(b, max_val=20.0)` | inverse of `norm2beta` | (0,max_val) → ℝ | natural → Gaussian |
| `softmax(evs, beta)` | `(evs, beta) -> ndarray` | — | numerically stable choice probabilities |

`norm2alpha` is `scipy.special.expit` (logistic). `norm2beta` is a logistic
scaled to `(0, max_val)`. Both accept scalars or arrays.

### `calc_fval` — the objective helper

Every `_fit` function ends by returning `calc_fval(...)` (except when
`output="all"`, which returns a diagnostics dict instead):

```python
def calc_fval(negll: float, params, prior=None, output: str = "npl") -> float:
    # output == "npl" and prior is not None:  return -(-negll + prior.logpdf(params))
    #                                          (the negative log posterior; capped at 1e7 if inf)
    # otherwise:                               return negll
```

- `output="npl"` (default): negative **log-posterior** — what the EM optimizer
  minimizes. Needs `prior`.
- `output="nll"`: negative **log-likelihood** — no prior term.
- The EM loop supplies `prior` for you; **pass it straight through, don't
  construct it yourself.**

---

## 4. The `_sim` / `_fit` contract

This is the glue that makes `EMModel.recover()` work — the two functions must
agree on names and order.

### `<modelname>_sim(params, **sim_kwargs) -> dict`

- `params`: natural-space "true" parameters, shape `(nsubjects, nparams)`.
  Column order must match `param_names`.
- `**sim_kwargs`: task-structure knobs (e.g. `nblocks=4, ntrials=24`). These are
  exactly the extra kwargs you pass to `.recover(...)`.
- **Returns a dict** that must contain:
  - `"params"`: echo the input `params` back (bookkeeping).
  - one key per behavioral-data array your `_fit` will consume, e.g.
    `"choices"`, `"rewards"`. **The first axis of each of these arrays is
    subjects** (length `nsubjects`) — `recover()` slices along it.

### `<modelname>_fit(params, *data_args, prior=None, output="npl")`

- `params`: **Gaussian (unbounded) space** — transform to natural space at the
  top, then bounds-check.
- `*data_args`: **one subject's** behavioral data, positionally, in the same
  order as `pr_inputs` (see below). For an RL model that's
  `(choices_of_one_subject, rewards_of_one_subject)`.
- Returns a scalar for `output` in `{"npl","nll"}`; returns a dict (must include
  an `"nll"` key and natural-space `"params"`) for `output="all"`.
- Bounds check: **return `1e7`, don't raise** — so the optimizer can back out of
  invalid regions. (The RW-family `_sim` functions are the one exception: they
  raise on out-of-bounds natural-space params, because those are caller-supplied
  "true" values, not optimizer proposals. Follow whichever your chosen reference
  does.)

---

## 5. `EMModel`

```python
model = EMModel(
    all_data,          # list of per-subject data rows, or None (recover builds it)
    fit_func,          # <modelname>_model.fit
    param_names,       # e.g. ["beta", "alpha"] — order matches everything else
    param_xform=None,  # list of Gaussian->natural fns, SAME length/order as param_names
    simulate_func=None # <modelname>_model.sim
)
```

`param_xform` must be the **same transforms, in the same order** as the ones
your `_fit` applies to `params[0]`, `params[1]`, … It's used to report estimated
parameters back in natural space. A length mismatch raises immediately.

### `.recover(true_params, pr_inputs, simulate_func=None, **sim_kwargs) -> dict`

The one-call parameter-recovery path — this is what the notebook should use.

```python
recovery = model.recover(
    true_params,                    # (nsubjects, nparams), natural space
    pr_inputs=["choices", "rewards"],  # which keys of the sim dict become fit args,
                                       # IN THE ORDER _fit expects them
    nblocks=nblocks, ntrials=ntrials   # forwarded to simulate_func
)
```

What it does internally: calls `simulate_func(true_params, **sim_kwargs)`, pulls
out the `pr_inputs` keys, builds `all_data` by zipping them per subject (so
`_fit` receives `(params, *row)`), fits with a fresh `EMModel`, then correlates
recovered vs. true parameters.

Returns a dict with:
- `"true_params"` — what you passed in
- `"estimated_params"` — `(nsubjects, nparams)`, **natural space** (transforms applied)
- `"correlation"` — per-parameter Pearson r, array of length `nparams`
- `"sim"` — the full simulation dict
- `"fit_result"` — a `FitResult` (see below)
- `"recovery_model"` — the fitted `EMModel`

**`pr_inputs` names must be keys returned by `_sim`, and their order must match
`_fit`'s positional `*data_args`.** This is the single most common source of a
broken recovery notebook.

### `.plot_recovery(recovery_dict, show_line=True, figsize=None, show=True) -> Figure`

Scatter of true vs. estimated for each parameter (3 columns, auto rows, x=y
line, annotated). Pass it the dict `.recover()` returned:

```python
fig = model.plot_recovery(recovery)
```

### `.fit(...) -> FitResult`

Fits `all_data` (must be non-None). All args are keyword-only. Common ones:
`verbose=1`, `njobs=-2`, `optim_method="BFGS"`, `max_restarts=2`, `seed=None`,
and prior overrides `prior_mu`/`prior_sigma` **or** `prior=` (not both).

`FitResult` fields: `m` (nparams × nsubjects, Gaussian space), `inv_h`,
`posterior_mu`, `posterior_sigma`, `NPL`, `NLPrior`, `NLL`, `convergence`.

### Other useful methods

- `.subject_params() -> (nsubjects, nparams)` natural-space per-subject estimates
  (transforms applied). Call after `.fit()`.
- `.posterior() -> {"mu":..., "sigma":...}` population-level posterior.
- `.compute_integrated_bic(nsamples=500, nll_key="nll", ntrials_total=None)` —
  integrated BIC; requires `_fit` to support `output="all"` returning an `"nll"`.
- `.compute_lme()` — Laplace log model evidence, returns `(per-subject, total, good-Hessian flags)`.
- `.scipy_minimize()` — per-subject independent fits (no shared prior); a
  lighter-weight alternative to full EM, mostly for quick checks.

---

## 6. Gaussian space vs natural space

The optimizer searches in **unbounded Gaussian space**; the psychology lives in
**bounded natural space**. Three places must stay consistent:

1. `_fit` receives `params` in **Gaussian** space → transforms to natural (via
   `norm2alpha`/`norm2beta`/custom) → bounds-checks → computes likelihood.
2. `param_xform` passed to `EMModel` is **the same list of transforms in the
   same order**, so estimated params are reported in natural space.
3. `_sim` receives and uses **natural**-space `params` directly (these are the
   "true" values), and `true_params` you build for `.recover()` are natural too.

If recovery correlations come out near zero, the first thing to check is that
these three orderings agree.

---

## Optional: model comparison

Out of scope for generating a single model, but if asked: `pyem.core.compare`
provides `ModelComparison` for comparing several fitted models via BIC/LME. A
generated model is compatible with it automatically (it just needs the standard
`_fit` with `output="all"`).
